# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

Admin UI for the `catchtechnology.com` mail server. The mail server itself is a separate repo at `../Catch technology Mail Server - Contabo/docker-mailserver/` (docker-mailserver, container `mail`, mailboxes managed via `./setup.sh email|alias|fail2ban ...`; see that repo's CLAUDE.md). Pushes to that repo's `main` deploy straight to production.

**Current state:** this app is not yet wired to the mail server. Mailbox CRUD only reads/writes the app's own SQLite `Email` table — creating an email here does not create a real mailbox. Real mailbox/alias/password/fail2ban operations must eventually go through docker-mailserver (`setup.sh` / `docker exec mail ...`), not only Prisma.

## Commands

```bash
npm run dev            # next dev (Turbopack), http://localhost:3000
npm run build          # production build
npm run lint           # eslint (flat config, eslint-config-next)
npm run lint:fix
npm run db:generate    # prisma generate — run after editing prisma/schema.prisma
npm run db:migrate     # prisma migrate dev --name init
npm run db:studio
npx prisma db seed     # runs prisma/seed.js
docker compose up --build   # container on :3000, bind-mounts prisma/dev.db
```

There is no test suite.

Requires a `.env` (gitignored) with `DATABASE_URL` pointing at the SQLite file (e.g. `file:./dev.db`).

## Architecture

- **Stack:** Next.js 16 App Router, React 19, Tailwind v4 (via `@tailwindcss/postcss`, no tailwind config file), Prisma 6 + SQLite, `react-icons`. `@/*` maps to `src/*`.
- **Data model** (`prisma/schema.prisma`): `User` = dashboard admins; `Email` = managed mailbox addresses (`status`, `resetToken`/`resetTokenExpiry` reserved for password resets). Prisma client singleton lives in `src/lib/prisma.ts`.
- **Auth:** `next-auth` is installed but unused. Login is custom: `src/app/page.tsx` (client) POSTs to `src/app/api/login/route.ts`, which compares the plaintext password against `User.password` and sets an httpOnly cookie `admin-auth=true`. Root `middleware.ts` only checks that cookie exists and only guards `/dashboard/:path*` — `/emails/[id]` and all `/api/*` routes are unprotected.
- **Data flow:** client components (`src/components/Emailtable.tsx`, `CreateEmailModal.tsx`) `fetch` the route handlers under `src/app/api/`; `src/app/emails/[id]/page.tsx` is a server component that queries Prisma directly.
- `src/services`, `src/repositories`, `src/hooks`, `src/types`, `src/utils` are empty placeholder barrels intended for future layering (e.g. a mail-server service wrapping `setup.sh`).

## Known gaps

- `Emailtable` calls `DELETE /api/emails/:id`, but no `src/app/api/emails/[id]/route.ts` exists, so delete always fails.
- `prisma/seed.js` creates the admin `User` without the required `password` field, so seeding fails until that's fixed.
- `api/login` logs request bodies (including passwords) and returns the full user record, password included.
