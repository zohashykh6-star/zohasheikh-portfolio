const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

async function main() {
  // Admin User
  await prisma.user.upsert({
    where: {
      email: "admin@catchtechnology.com",
    },
    update: {},
    create: {
      name: "Admin User",
      email: "admin@catchtechnology.com",
      password: "admin123",
    },
  });

  // Company Email Records
  const emails = [
    "ahmedgadit@catchtechnology.com",
    "mustafagadit@catchtechnology.com",
    "ahmedrizwan@catchtechnology.com",
    "usamagadit@catchtechnology.com",
    "hr@catchtechnology.com",
    "no-reply@catchtechnology.com",
    "support@catchtechnology.com",
    "help@catchtechnology.com",
    "alerts@catchtechnology.com",
    "fail2ban@catchtechnology.com",
    "finance@catchtechnology.com",
  ];

  for (const email of emails) {
    await prisma.email.upsert({
      where: {
        email: email,
      },
      update: {},
      create: {
        email: email,
        status: "active",
      },
    });
  }

  console.log("✅ Database seeded successfully");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });