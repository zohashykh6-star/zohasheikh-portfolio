'use client';

import { useEffect, useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/footer';
import {
  Server,
  Mail,
  Shield,
  CheckCircle2,
  XCircle,
  Eye,
  EyeOff,
} from 'lucide-react';

export default function SMTPPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [sendingTestEmail, setSendingTestEmail] = useState(false);

  const [message, setMessage] = useState('');
  const [messageType, setMessageType] =
    useState<'success' | 'error'>('success');

  const showToast = (
    text: string,
    type: 'success' | 'error' = 'success'
  ) => {
    setMessage(text);
    setMessageType(type);

    setTimeout(() => {
      setMessage('');
    }, 3000);
  };

  const [form, setForm] = useState({
    smtpHost: '',
    smtpPort: '',
    email: '',
    password: '',
  });

  const [testEmail, setTestEmail] = useState('');

  useEffect(() => {
    async function loadSettings() {
      try {
        const res = await fetch('/api/smtp');

        if (!res.ok) {
          setLoading(false);
          return;
        }

        const data = await res.json();

        if (data) {
          setForm({
            smtpHost: data.smtpHost || '',
            smtpPort: String(data.smtpPort || ''),
            email: data.email || '',
            password: data.password || '',
          });
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    loadSettings();
  }, []);

  const handleChange = (
    field: keyof typeof form,
    value: string
  ) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSave = async () => {
    if (
      !form.smtpHost.trim() ||
      !form.smtpPort.trim() ||
      !form.email.trim() ||
      !form.password.trim()
    ) {
      showToast('Please fill in all fields.', 'error');
      return;
    }

    setSaving(true);

    try {
      const response = await fetch('/api/smtp', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(form),
      });

      const data = await response.json();

      if (!response.ok) {
        showToast(
          data.error || 'Failed to save SMTP settings.',
          'error'
        );
        return;
      }

      showToast(
        'SMTP settings saved successfully.',
        'success'
      );
    } catch (error) {
      console.error(error);

      showToast(
        'Something went wrong. Please try again.',
        'error'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleTestConnection = async () => {
    if (
      !form.smtpHost.trim() ||
      !form.smtpPort.trim() ||
      !form.email.trim() ||
      !form.password.trim()
    ) {
      showToast(
        'Please fill in all fields before testing.',
        'error'
      );
      return;
    }

    setTesting(true);

    try {
      const response = await fetch('/api/smtp/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (!response.ok) {
        showToast(
          data.error || 'SMTP Connection Failed',
          'error'
        );
        return;
      }

      showToast(
        data.message || 'SMTP Connection Successful!',
        'success'
      );
    } catch (error) {
      console.error(error);

      showToast(
        'Unable to connect to SMTP server.',
        'error'
      );
    } finally {
      setTesting(false);
    }
  };

  const handleSendTestEmail = async () => {
    if (!testEmail.trim()) {
      showToast('Please enter recipient email.', 'error');
      return;
    }

    setSendingTestEmail(true);

    try {
      const response = await fetch('/api/smtp/send-test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: testEmail,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        showToast(
          data.message || 'Failed to send test email.',
          'error'
        );
        return;
      }

      showToast(
        data.message || 'Test email sent successfully.',
        'success'
      );
    } catch (error) {
      console.error(error);

      showToast(
        'Unable to send test email.',
        'error'
      );
    } finally {
      setSendingTestEmail(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070B17]">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-8">
        <Header />

        <div className="mt-8 rounded-2xl border border-slate-800 bg-[#111827] p-8">
          <div className="mb-8 flex items-center gap-4">
            <div className="rounded-xl bg-cyan-500/10 p-4">
              <Server className="h-8 w-8 text-cyan-400" />
            </div>

            <div>
              <h1 className="text-3xl font-bold text-white">
                SMTP Settings
              </h1>

              <p className="mt-1 text-slate-400">
                Configure your outgoing mail server.
              </p>
            </div>
          </div>

          {/* Toast message */}
          {message && (
            <div
              className={`mb-6 flex items-center gap-2 rounded-xl border px-4 py-3 text-sm ${
                messageType === 'success'
                  ? 'border-emerald-800 bg-emerald-500/10 text-emerald-400'
                  : 'border-red-800 bg-red-500/10 text-red-400'
              }`}
            >
              {messageType === 'success' ? (
                <CheckCircle2 size={18} />
              ) : (
                <XCircle size={18} />
              )}
              <span>{message}</span>
            </div>
          )}

          {loading ? (
            <div className="py-10 text-center text-slate-400">
              Loading settings...
            </div>
          ) : (
            <>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm text-slate-400">
                    SMTP Host
                  </label>
                  <input
                    type="text"
                    value={form.smtpHost}
                    onChange={(e) =>
                      handleChange('smtpHost', e.target.value)
                    }
                    placeholder="smtp.gmail.com"
                    className="w-full rounded-xl border border-slate-700 bg-[#0F172A] px-4 py-3 text-white outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm text-slate-400">
                    SMTP Port
                  </label>
                  <input
                    type="number"
                    value={form.smtpPort}
                    onChange={(e) =>
                      handleChange('smtpPort', e.target.value)
                    }
                    placeholder="587"
                    className="w-full rounded-xl border border-slate-700 bg-[#0F172A] px-4 py-3 text-white outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm text-slate-400">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail
                      className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"
                      size={18}
                    />
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) =>
                        handleChange('email', e.target.value)
                      }
                      placeholder="admin@example.com"
                      className="w-full rounded-xl border border-slate-700 bg-[#0F172A] py-3 pl-11 pr-4 text-white outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-2 block text-sm text-slate-400">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={form.password}
                      onChange={(e) =>
                        handleChange('password', e.target.value)
                      }
                      placeholder="********"
                      className="w-full rounded-xl border border-slate-700 bg-[#0F172A] px-4 py-3 pr-12 text-white outline-none focus:border-cyan-500"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setShowPassword(!showPassword)
                      }
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400"
                    >
                      {showPassword ? (
                        <EyeOff size={18} />
                      ) : (
                        <Eye size={18} />
                      )}
                    </button>
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="mb-2 block text-sm text-slate-400">
                    Test Recipient Email
                  </label>

                  <input
                    type="email"
                    value={testEmail}
                    onChange={(e) => setTestEmail(e.target.value)}
                    placeholder="example@gmail.com"
                    className="w-full rounded-xl border border-slate-700 bg-[#0F172A] px-4 py-3 text-white outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="mt-6 flex items-start gap-2 rounded-xl border border-slate-800 bg-slate-900/40 px-4 py-3 text-xs text-slate-400">
                <Shield size={16} className="mt-0.5 shrink-0 text-cyan-400" />
                <span>
                  Credentials are transmitted to your server and stored
                  according to your app&apos;s configuration. Use an app
                  password where your provider supports it, instead of your
                  main account password.
                </span>
              </div>

              <div className="mt-8 flex flex-wrap gap-4">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="rounded-xl bg-cyan-600 px-6 py-3 font-semibold text-white transition hover:bg-cyan-700 disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Settings'}
                </button>

                <button
                  onClick={handleTestConnection}
                  disabled={testing}
                  className="rounded-xl border border-slate-700 px-6 py-3 text-white transition hover:bg-slate-800 disabled:opacity-50"
                >
                  {testing ? 'Testing...' : 'Test Connection'}
                </button>

                <button
                  onClick={handleSendTestEmail}
                  disabled={sendingTestEmail}
                  className="rounded-xl bg-green-600 px-6 py-3 font-semibold text-white transition hover:bg-green-700 disabled:opacity-50"
                >
                  {sendingTestEmail ? 'Sending...' : 'Send Test Email'}
                </button>
              </div>
            </>
          )}
        </div>

        <Footer />
      </div>
    </div>
  );
}