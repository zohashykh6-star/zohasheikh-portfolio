import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const totalEmails = await prisma.email.count();

    const activeEmails = await prisma.email.count({
      where: {
        status: "active",
      },
    });

    const disabledEmails = await prisma.email.count({
      where: {
        status: {
          not: "active",
        },
      },
    });

    return NextResponse.json({
      totalEmails,
      activeEmails,
      disabledEmails,
      serverStatus: "Online",
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        totalEmails: 0,
        activeEmails: 0,
        disabledEmails: 0,
        serverStatus: "Offline",
      },
      { status: 500 }
    );
  }
}