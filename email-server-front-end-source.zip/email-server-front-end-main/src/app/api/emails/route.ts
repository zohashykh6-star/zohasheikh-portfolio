import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const emails = await prisma.email.findMany({
      orderBy: {
        id: "asc",
      },
    });

    return NextResponse.json(emails);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Failed to fetch emails" },
      { status: 500 }
    );
  }
}