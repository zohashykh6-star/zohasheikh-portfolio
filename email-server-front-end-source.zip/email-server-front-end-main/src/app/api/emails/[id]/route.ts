import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET ALL EMAILS
export async function GET() {
  try {
    const emails = await prisma.email.findMany({
      orderBy: {
        id: "asc",
      },
    });

    return NextResponse.json(emails);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Failed to fetch emails",
      },
      {
        status: 500,
      }
    );
  }
}

// CREATE EMAIL
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const { email, password, status } = body;

    if (!email || !password) {
      return NextResponse.json(
        {
          success: false,
          message: "Email and password are required.",
        },
        {
          status: 400,
        }
      );
    }

    const exists = await prisma.email.findUnique({
      where: {
        email,
      },
    });

    if (exists) {
      return NextResponse.json(
        {
          success: false,
          message: "Email already exists.",
        },
        {
          status: 400,
        }
      );
    }

    const newEmail = await prisma.email.create({
      data: {
        email,
        password,
        status: status || "active",
      },
    });

    return NextResponse.json({
      success: true,
      message: "Email created successfully.",
      data: newEmail,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        success: false,
        message: "Failed to create email.",
      },
      {
        status: 500,
      }
    );
  }
}