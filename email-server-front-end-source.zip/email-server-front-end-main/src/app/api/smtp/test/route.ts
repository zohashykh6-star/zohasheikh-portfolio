import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import nodemailer from "nodemailer";

export async function POST() {
  try {
    const setting = await prisma.smtpSetting.findFirst();

    if (!setting) {
      return NextResponse.json(
        { success: false, message: "SMTP settings not found." },
        { status: 404 }
      );
    }

    const transporter = nodemailer.createTransport({
      host: setting.smtpHost,
      port: Number(setting.smtpPort),
      secure: Number(setting.smtpPort) === 465,
      auth: {
        user: setting.email,
        pass: setting.password,
      },
    });

    await transporter.verify();

    return NextResponse.json({
      success: true,
      message: "SMTP connection successful.",
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        success: false,
        message: "SMTP connection failed.",
      },
      { status: 500 }
    );
  }
}