import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import nodemailer from "nodemailer";

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json();

    if (!email) {
      return NextResponse.json(
        { message: "Recipient email is required." },
        { status: 400 }
      );
    }

    const setting = await prisma.smtpSetting.findFirst();

    if (!setting) {
      return NextResponse.json(
        { message: "SMTP settings not found." },
        { status: 404 }
      );
    }

    const transporter = nodemailer.createTransport({
      host: setting.smtpHost,
      port: Number(setting.smtpPort),
      secure: Number(setting.smtpPort) === 465,
      auth: {
        user: setting.email,
        pass: setting.password,
      },
    });

    await transporter.sendMail({
      from: setting.email,
      to: email,
      subject: "SMTP Test Email",
      html: `
        <div style="font-family: Arial, sans-serif;">
          <h2>SMTP Test Successful ✅</h2>
          <p>This is a test email from the Catch Technology Email Management System.</p>
          <hr />
          <p>If you received this email, your SMTP configuration is working correctly.</p>
        </div>
      `,
    });

    return NextResponse.json({
      success: true,
      message: "Test email sent successfully.",
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        success: false,
        message: "Failed to send test email.",
      },
      {
        status: 500,
      }
    );
  }
}