import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET SMTP Settings
export async function GET() {
  try {
    const setting = await prisma.smtpSetting.findFirst();

    if (!setting) {
      return NextResponse.json(null, { status: 200 });
    }

    return NextResponse.json(setting);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Failed to load SMTP settings" },
      { status: 500 }
    );
  }
}

// SAVE SMTP Settings
export async function PUT(req: Request) {
  try {
    const body = await req.json();

    const { smtpHost, smtpPort, email, password } = body;

    const existing = await prisma.smtpSetting.findFirst();

    let setting;

    if (existing) {
      setting = await prisma.smtpSetting.update({
        where: {
          id: existing.id,
        },
        data: {
          smtpHost,
          smtpPort: Number(smtpPort),
          email,
          password,
        },
      });
    } else {
      setting = await prisma.smtpSetting.create({
        data: {
          smtpHost,
          smtpPort: Number(smtpPort),
          email,
          password,
        },
      });
    }

    return NextResponse.json(setting);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Failed to save SMTP settings" },
      { status: 500 }
    );
  }
}