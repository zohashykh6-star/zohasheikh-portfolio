'use client';

import Header from '../../components/Header';
import EmailTable from '../../components/Emailtable';
import Footer from '../../components/footer';

export default function EmailsPage() {
  return (
    <div className="min-h-screen bg-[#070B17]">
      <div className="mx-auto max-w-7xl px-8 py-8">

        <Header />

        {/* Email Table */}
        <div className="mt-8">
          <EmailTable />
        </div>

        {/* Footer */}
        <Footer />

      </div>
    </div>
  );
}