'use client';

import { useParams, useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/footer';
import {
  Mail,
  User,
  CheckCircle2,
  ArrowLeft,
} from 'lucide-react';

export default function EmailDetailsPage() {
  const params = useParams();
  const router = useRouter();

  return (
    <div className="min-h-screen bg-[#070B17]">
      <div className="mx-auto max-w-7xl px-8 py-8">

        <Header />

        <div className="mt-8 rounded-2xl border border-slate-800 bg-[#111827] p-8">

          <div className="mb-8 flex items-center justify-between">

            <div className="flex items-center gap-4">

              <div className="rounded-xl bg-cyan-500/10 p-4">
                <Mail className="h-8 w-8 text-cyan-400" />
              </div>

              <div>
                <h1 className="text-3xl font-bold text-white">
                  Email Details
                </h1>

                <p className="mt-2 text-slate-400">
                  Email ID : {params.id}
                </p>
              </div>

            </div>

            <button
              onClick={() => router.back()}
              className="flex items-center gap-2 rounded-xl bg-cyan-600 px-5 py-3 font-semibold text-white hover:bg-cyan-700"
            >
              <ArrowLeft size={18} />
              Back
            </button>

          </div>

          <div className="grid gap-6 md:grid-cols-2">

            <div className="rounded-xl border border-slate-700 bg-[#0F172A] p-6">
              <Mail className="mb-3 h-6 w-6 text-cyan-400" />

              <h3 className="font-semibold text-white">
                Email Address
              </h3>

              <p className="mt-2 text-slate-400">
                example@catchtechnology.com
              </p>
            </div>

            <div className="rounded-xl border border-slate-700 bg-[#0F172A] p-6">
              <User className="mb-3 h-6 w-6 text-green-400" />

              <h3 className="font-semibold text-white">
                Owner
              </h3>

              <p className="mt-2 text-slate-400">
                Administrator
              </p>
            </div>

            <div className="rounded-xl border border-slate-700 bg-[#0F172A] p-6">
              <CheckCircle2 className="mb-3 h-6 w-6 text-green-400" />

              <h3 className="font-semibold text-white">
                Status
              </h3>

              <span className="mt-2 inline-block rounded-full bg-green-500/10 px-3 py-1 text-sm font-semibold text-green-400">
                Active
              </span>
            </div>

            <div className="rounded-xl border border-slate-700 bg-[#0F172A] p-6">
              <h3 className="font-semibold text-white">
                Description
              </h3>

              <p className="mt-2 text-slate-400">
                Email account details will be loaded here from the database.
              </p>
            </div>

          </div>

        </div>

        <Footer />

      </div>
    </div>
  );
}