import "./globals.css";
import type { Metadata } from "next";
import Sidebar from "@/components/Sidebar";
import { Geist } from "next/font/google";
import { cn } from "@/lib/utils";

const geist = Geist({subsets:['latin'],variable:'--font-sans'});

export const metadata: Metadata = {
  title: "Catch Technology",
  description: "Enterprise Email Management System",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={cn("overflow-x-hidden", "font-sans", geist.variable)}>
      <body className="bg-[#050816] overflow-x-hidden">
        <Sidebar />

        <main className="min-h-screen lg:ml-56 overflow-x-hidden">
          {children}
        </main>
      </body>
    </html>
  );
}