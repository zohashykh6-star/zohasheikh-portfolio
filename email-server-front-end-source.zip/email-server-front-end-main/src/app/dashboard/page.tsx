'use client';

import { useEffect, useState } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/footer';
import DashboardChart from '@/components/DashboardChart';

import {
  Mail,
  CheckCircle2,
  XCircle,
  Server,
} from 'lucide-react';

export default function DashboardPage() {
  const [stats, setStats] = useState({
    totalEmails: 0,
    activeEmails: 0,
    disabledEmails: 0,
    serverStatus: 'Offline',
  });

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const res = await fetch('/api/dashboard');

        if (!res.ok) return;

        const data = await res.json();
        setStats(data);
      } catch (error) {
        console.error(error);
      }
    };

    fetchDashboard();
  }, []);

  return (
    <div className="min-h-screen bg-[#070B17]">
      <div className="mx-auto max-w-7xl px-8 py-8">

        <Header />

        {/* Statistics */}
        <section className="mt-8 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">

          {/* Total Emails */}
          <div className="rounded-2xl border border-slate-800 bg-[#111827] p-6 shadow-lg transition hover:border-cyan-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">
                  Total Emails
                </p>

                <h2 className="mt-2 text-4xl font-bold text-white">
                  {stats.totalEmails}
                </h2>
              </div>

              <div className="rounded-xl bg-cyan-500/10 p-4">
                <Mail className="h-7 w-7 text-cyan-400" />
              </div>
            </div>
          </div>

          {/* Active Emails */}
          <div className="rounded-2xl border border-slate-800 bg-[#111827] p-6 shadow-lg transition hover:border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">
                  Active Emails
                </p>

                <h2 className="mt-2 text-4xl font-bold text-white">
                  {stats.activeEmails}
                </h2>
              </div>

              <div className="rounded-xl bg-green-500/10 p-4">
                <CheckCircle2 className="h-7 w-7 text-green-400" />
              </div>
            </div>
          </div>

          {/* Disabled Emails */}
          <div className="rounded-2xl border border-slate-800 bg-[#111827] p-6 shadow-lg transition hover:border-red-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">
                  Disabled Emails
                </p>

                <h2 className="mt-2 text-4xl font-bold text-white">
                  {stats.disabledEmails}
                </h2>
              </div>

              <div className="rounded-xl bg-red-500/10 p-4">
                <XCircle className="h-7 w-7 text-red-400" />
              </div>
            </div>
          </div>

          {/* Server Status */}
          <div className="rounded-2xl border border-slate-800 bg-[#111827] p-6 shadow-lg transition hover:border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">
                  Server Status
                </p>

                <h2
                  className={`mt-2 text-4xl font-bold ${
                    stats.serverStatus === 'Online'
                      ? 'text-green-400'
                      : 'text-red-400'
                  }`}
                >
                  {stats.serverStatus}
                </h2>
              </div>

              <div className="rounded-xl bg-blue-500/10 p-4">
                <Server className="h-7 w-7 text-blue-400" />
              </div>
            </div>
          </div>

        </section>

        <DashboardChart
          total={stats.totalEmails}
          active={stats.activeEmails}
          disabled={stats.disabledEmails}
        />

        <Footer />

      </div>
    </div>
  );
}