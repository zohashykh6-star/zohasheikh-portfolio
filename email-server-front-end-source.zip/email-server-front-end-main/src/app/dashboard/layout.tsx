import { ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

export default function DashboardLayout({ children }: Props) {
  return (
    <main className="min-h-screen overflow-y-auto p-8">
      {children}
    </main>
  );
}