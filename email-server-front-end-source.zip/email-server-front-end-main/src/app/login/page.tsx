'use client';

import Image from 'next/image';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    setLoading(true);
    setError('');

    const result = await signIn('credentials', {
      email,
      password,
      redirect: false,
    });

    setLoading(false);

    if (result?.error) {
      setError('Invalid email or password');
      return;
    }

    router.push('/dashboard');
    router.refresh();
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#050816]">

      {/* Background */}
      <div className="absolute inset-0">

        <div className="absolute inset-0 bg-gradient-to-br from-[#07142a] via-[#050816] to-[#02040a]" />

        <div className="absolute -left-40 top-0 h-[500px] w-[500px] rounded-full bg-cyan-500/10 blur-[170px]" />

        <div className="absolute -right-32 bottom-0 h-[450px] w-[450px] rounded-full bg-blue-600/10 blur-[170px]" />

      </div>

      {/* Watermark Logo */}
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.05]">

        <Image
          src="/logo.png"
          alt="Catch Technology"
          width={700}
          height={700}
          priority
        />

      </div>
            {/* Login Card */}

      <div className="relative z-10 w-full max-w-md">

        <div className="rounded-[32px] border border-cyan-500/20 bg-slate-900/70 p-10 shadow-[0_0_80px_rgba(0,180,255,0.15)] backdrop-blur-2xl">

          <div className="mb-8 flex flex-col items-center">

            <div className="mb-5 rounded-3xl border border-cyan-500/20 bg-white p-4 shadow-xl">

              <Image
                src="/logo.png"
                alt="Catch Technology"
                width={95}
                height={95}
                priority
              />

            </div>

            <h1 className="text-center text-4xl font-extrabold text-white">

              Catch Technology

            </h1>

            <p className="mt-3 text-center text-slate-400">

              Enterprise Email Management System

            </p>

          </div>

          {error && (

            <div className="mb-6 rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-center text-sm text-red-400">

              {error}

            </div>

          )}

          <form onSubmit={handleLogin}>

            <div className="mb-5">

              <label className="mb-2 block text-sm font-medium text-slate-300">

                Company Email

              </label>

              <input
                type="email"
                placeholder="admin@catchtechnology.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-2xl border border-slate-700 bg-slate-800/80 px-5 py-4 text-white outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                required
              />

            </div>

            <div className="mb-8">

              <label className="mb-2 block text-sm font-medium text-slate-300">

                Password

              </label>

              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-2xl border border-slate-700 bg-slate-800/80 px-5 py-4 text-white outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                required
              />
                          </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-600 py-4 text-lg font-bold text-white shadow-lg shadow-cyan-500/30 transition duration-300 hover:scale-[1.02] hover:shadow-cyan-500/50 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? 'Signing In...' : 'Sign In'}
            </button>

          </form>

          <div className="mt-8 flex items-center justify-center">

            <div className="rounded-full border border-cyan-500/20 bg-cyan-500/10 px-5 py-2">

              <span className="text-sm font-semibold tracking-wide text-cyan-400">
                Secure Authentication
              </span>

            </div>

          </div>

        </div>

      </div>
            {/* Bottom Glow */}

      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-52 bg-gradient-to-t from-cyan-500/10 to-transparent" />

      {/* Footer */}

      <div className="absolute bottom-6 left-0 right-0 text-center">

        <p className="text-sm tracking-wide text-slate-500">

          © 2026 Catch Technology. All Rights Reserved.

        </p>

      </div>

    </div>
  );
}