'use client';

import { Bell, Search } from 'lucide-react';

export default function TopNavbar() {
  return (
    <header className="mb-6 flex h-16 items-center justify-between rounded-2xl border border-slate-800 bg-[#0B1220] px-6">

      {/* Left */}

      <div>

        <h1 className="text-2xl font-bold text-white">
          Dashboard
        </h1>

        <p className="mt-1 text-xs text-slate-400">
          Enterprise Email Management
        </p>

      </div>

      {/* Right */}

      <div className="flex items-center gap-3">

        {/* Search */}

        <div className="flex h-10 w-72 items-center rounded-xl border border-slate-700 bg-slate-900 px-3">

          <Search
            size={17}
            className="mr-2 text-slate-500"
          />

          <input
            type="text"
            placeholder="Search..."
            className="w-full bg-transparent text-sm text-white outline-none placeholder:text-slate-500"
          />

        </div>

        {/* Notification */}

        <button className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-slate-700 bg-slate-900 hover:border-cyan-500">

          <Bell
            size={18}
            className="text-white"
          />

          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-cyan-500"></span>

        </button>
                {/* Admin */}

        <div className="flex items-center gap-3 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2">

          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-sm font-bold text-white">
            A
          </div>

          <div>

            <p className="text-sm font-semibold text-white">
              Administrator
            </p>

            <p className="text-xs text-slate-400">
              admin@catchtechnology.com
            </p>

          </div>

        </div>

      </div>

    </header>
  );
}
