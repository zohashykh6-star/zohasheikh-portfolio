'use client';

import { useEffect, useState } from 'react';
import { Bell, ArrowLeft } from 'lucide-react';
import { signOut } from 'next-auth/react';
import { useRouter } from 'next/navigation';

export default function Header() {
  const router = useRouter();

  const [currentTime, setCurrentTime] = useState<Date | null>(null);

  useEffect(() => {
    const updateTime = () => {
      setCurrentTime(new Date());
    };

    updateTime();

    const timer = setInterval(updateTime, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleLogout = async () => {
    await signOut({ redirect: false });
    router.push('/login');
  };

  const handleBack = () => {
    router.back();
  };

  return (
    <header className="mb-8 rounded-2xl border border-slate-800 bg-[#111827] px-5 py-5 shadow-lg lg:px-8">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">

        {/* Left */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">
            Dashboard
          </h1>

          <p className="mt-1 text-sm text-slate-400">
            Welcome to Catch Technology Email Management System
          </p>
        </div>

        {/* Right */}
        <div className="flex flex-wrap items-center gap-3 lg:flex-nowrap">

          {/* Date & Time */}
          <div className="rounded-xl border border-slate-700 bg-[#0F172A] px-4 py-2 text-right">
            <p className="text-xs text-slate-400">
              {currentTime
                ? currentTime.toLocaleDateString('en-US', {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })
                : '--'}
            </p>

            <p className="text-lg font-bold text-cyan-400">
              {currentTime
                ? currentTime.toLocaleTimeString()
                : '--:--:--'}
            </p>
          </div>

          {/* Back Button */}
          <button
            onClick={handleBack}
            className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-700 bg-[#0F172A] text-white transition hover:border-cyan-500 lg:h-auto lg:w-auto lg:px-4 lg:py-3"
          >
            <ArrowLeft size={18} />
            <span className="ml-2 hidden lg:inline">
              Back
            </span>
          </button>

          {/* Notification */}
          <button className="relative flex h-12 w-12 items-center justify-center rounded-xl border border-slate-700 bg-[#0F172A] transition hover:border-cyan-500">
            <Bell size={20} className="text-slate-300" />
            <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-cyan-400"></span>
          </button>

          {/* Admin */}
          <div className="flex items-center gap-3 rounded-xl border border-slate-700 bg-[#0F172A] px-3 py-2">

            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-sm font-bold text-white">
              A
            </div>

            <div className="hidden sm:block">
              <h3 className="font-semibold text-white">
                Administrator
              </h3>

              <p className="text-xs text-slate-400">
                Catch Technology
              </p>
            </div>

          </div>

          {/* Logout */}
          <button
            onClick={handleLogout}
            className="rounded-xl bg-red-600 px-4 py-3 font-semibold text-white transition hover:bg-red-700"
          >
            Logout
          </button>

        </div>
      </div>
    </header>
  );
}