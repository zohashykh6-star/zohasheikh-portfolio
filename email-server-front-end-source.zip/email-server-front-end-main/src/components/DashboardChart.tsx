'use client';

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface DashboardChartProps {
  total: number;
  active: number;
  disabled: number;
}

export default function DashboardChart({
  total,
  active,
  disabled,
}: DashboardChartProps) {
  const data = [
    {
      name: 'Total',
      value: total,
      color: '#3B82F6', // Blue
    },
    {
      name: 'Active',
      value: active,
      color: '#22C55E', // Green
    },
    {
      name: 'Disabled',
      value: disabled,
      color: '#EF4444', // Red
    },
  ];

  return (
    <div className="mt-10 rounded-2xl border border-slate-800 bg-[#111827] p-6 shadow-lg">
      <h2 className="mb-6 text-3xl font-bold text-white">
        Email Statistics
      </h2>

      {/* Smaller Chart */}
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            barCategoryGap="45%"
          >
            <CartesianGrid
              stroke="#374151"
              strokeDasharray="3 3"
            />

            <XAxis
              dataKey="name"
              stroke="#94A3B8"
            />

            <YAxis
              stroke="#94A3B8"
            />

            <Tooltip />

            <Bar
              dataKey="value"
              radius={[8, 8, 0, 0]}
              barSize={55}
            >
              {data.map((entry, index) => (
                <Cell
                  key={index}
                  fill={entry.color}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}