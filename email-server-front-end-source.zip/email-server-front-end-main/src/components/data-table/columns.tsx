"use client";

import { ColumnDef } from "@tanstack/react-table";
import { Eye, RotateCcw, Trash2 } from "lucide-react";

export type Email = {
  id: number;
  email: string;
  status: string;
};

export const columns = (
  onDelete: (id: number) => void
): ColumnDef<Email>[] => [
  {
    accessorKey: "id",
    header: "ID",
    cell: ({ row }) => (
      <span className="font-medium text-slate-300">
        #{row.original.id}
      </span>
    ),
  },
  {
    accessorKey: "email",
    header: "Email Address",
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => (
      <span className="rounded-full bg-green-500/10 px-3 py-1 text-xs font-medium text-green-400">
        {row.original.status}
      </span>
    ),
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => (
      <div className="flex justify-center gap-2">
        <a
          href={`/emails/${row.original.id}`}
          className="rounded-lg border border-cyan-600 p-2 text-cyan-400 transition hover:bg-cyan-600 hover:text-white"
        >
          <Eye size={18} />
        </a>

        <button
          onClick={() =>
            alert(`Reset password for ${row.original.email}`)
          }
          className="rounded-lg border border-yellow-500 p-2 text-yellow-400 transition hover:bg-yellow-500 hover:text-white"
        >
          <RotateCcw size={18} />
        </button>

        <button
          onClick={() => onDelete(row.original.id)}
          className="rounded-lg border border-red-500 p-2 text-red-400 transition hover:bg-red-600 hover:text-white"
        >
          <Trash2 size={18} />
        </button>
      </div>
    ),
  },
];