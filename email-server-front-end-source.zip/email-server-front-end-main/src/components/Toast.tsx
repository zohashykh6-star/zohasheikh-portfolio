'use client';

import { CheckCircle2, XCircle } from 'lucide-react';

interface ToastProps {
  show: boolean;
  type: 'success' | 'error';
  message: string;
}

export default function Toast({
  show,
  type,
  message,
}: ToastProps) {
  if (!show) return null;

  return (
    <div className="fixed right-6 top-6 z-[9999] animate-in slide-in-from-right duration-300">

      <div
        className={`flex items-center gap-3 rounded-xl border px-5 py-4 shadow-2xl backdrop-blur-md ${
          type === 'success'
            ? 'border-green-500/30 bg-green-500/10'
            : 'border-red-500/30 bg-red-500/10'
        }`}
      >
        {type === 'success' ? (
          <CheckCircle2 className="text-green-400" size={22} />
        ) : (
          <XCircle className="text-red-400" size={22} />
        )}

        <span
          className={`font-medium ${
            type === 'success'
              ? 'text-green-300'
              : 'text-red-300'
          }`}
        >
          {message}
        </span>
      </div>

    </div>
  );
}