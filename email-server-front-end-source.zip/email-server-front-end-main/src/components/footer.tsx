'use client';

import { ShieldCheck } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="mt-10 rounded-2xl border border-slate-800 bg-[#111827] px-8 py-6">

      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">

        <div>
          <h3 className="text-2xl font-bold text-white">
            Catch Technology
          </h3>

          <p className="mt-2 text-slate-400">
            Enterprise Email Management Dashboard
          </p>
        </div>

        <div className="flex items-center gap-3 rounded-xl border border-green-500/20 bg-green-500/10 px-5 py-3">
          <span className="h-3 w-3 animate-pulse rounded-full bg-green-400"></span>
          <ShieldCheck className="h-5 w-5 text-green-400" />
          <span className="font-semibold text-green-400">
            System Operational
          </span>
        </div>

      </div>

      <div className="mt-6 border-t border-slate-800 pt-4 text-center text-sm text-slate-500">
        © 2026 Catch Technology. All rights reserved.
      </div>

    </footer>
  );
}