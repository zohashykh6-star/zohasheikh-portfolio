'use client';

import { Bell, Search } from 'lucide-react';

export default function TopNavbar() {
  return (
    <header className="sticky top-0 z-40 mb-8 flex h-20 items-center justify-end rounded-3xl border border-slate-800 bg-[#0B1220]/90 px-6 backdrop-blur-xl">

      <div className="flex items-center gap-4">

        {/* Search */}
        <div className="flex h-11 w-72 items-center gap-3 rounded-2xl border border-slate-700 bg-slate-900 px-4">
          <Search size={18} className="text-slate-500" />

          <input
            type="text"
            placeholder="Search emails..."
            className="w-full bg-transparent text-sm text-white outline-none placeholder:text-slate-500"
          />
        </div>

        {/* Notification */}
        <button className="relative flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-700 bg-slate-900 transition hover:border-cyan-500">
          <Bell size={18} className="text-white" />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-cyan-400"></span>
        </button>

        {/* Admin */}
        <div className="flex items-center gap-3 rounded-2xl border border-slate-700 bg-slate-900 px-4 py-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 font-bold text-white">
            A
          </div>

          <div>
            <p className="text-sm font-semibold text-white">
              Administrator
            </p>

            <p className="text-xs text-slate-400">
              admin@catchtechnology.com
            </p>
          </div>
        </div>

      </div>
    </header>
  );
}