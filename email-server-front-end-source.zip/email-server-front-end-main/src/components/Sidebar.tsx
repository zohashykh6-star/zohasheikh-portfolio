'use client';

import Image from 'next/image';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

import {
  LayoutDashboard,
  Mail,
  Server,
} from 'lucide-react';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/emails', label: 'Email Records', icon: Mail },
  { href: '/smtp', label: 'SMTP Settings', icon: Server },
];

export default function Sidebar() {
  const pathname = usePathname();

  const isActive = (href: string) =>
    pathname === href || pathname.startsWith(href + '/');

  return (
    <>
      {/* ---------- DESKTOP SIDEBAR (left side) ---------- */}
      <aside className="fixed top-0 left-0 z-50 hidden h-screen w-56 flex-col border-r border-slate-800 bg-[#08111F] lg:flex">
        <div className="flex h-24 items-center justify-center border-b border-slate-800">
          <Image
            src="/logo.png"
            alt="Catch Technology"
            width={110}
            height={110}
            priority
          />
        </div>

        <nav className="flex-1 space-y-3 px-4 py-6">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
            const active = isActive(href);

            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-3 rounded-xl px-4 py-3 transition ${
                  active
                    ? 'bg-cyan-500/10 text-cyan-400'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Icon size={20} />
                <span className="text-base font-bold">
                  {label}
                </span>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* ---------- MOBILE TOP BAR (logo only) ---------- */}
      <div className="fixed top-0 left-0 right-0 z-50 flex h-16 items-center justify-center border-b border-slate-800 bg-[#08111F] lg:hidden">
        <Image
          src="/logo.png"
          alt="Catch Technology"
          width={40}
          height={40}
          priority
        />
      </div>

      {/* ---------- MOBILE BOTTOM NAVIGATION BAR ---------- */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 flex h-16 items-center justify-around border-t border-slate-800 bg-[#08111F] lg:hidden">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = isActive(href);

          return (
            <Link
              key={href}
              href={href}
              className={`flex flex-1 flex-col items-center justify-center gap-1 py-2 transition ${
                active ? 'text-cyan-400' : 'text-slate-400'
              }`}
            >
              <Icon size={22} />
              <span className="text-[11px] font-semibold">
                {label}
              </span>
            </Link>
          );
        })}
      </nav>
    </>
  );
}