'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Search,
  Eye,
  RotateCcw,
  Trash2,
  Mail,
  X,
  Lock,
  EyeOff,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
} from 'lucide-react';

type Email = {
  id: number;
  email: string;
  status: string;
};

type SortField = 'id' | 'email' | 'status';
type SortOrder = 'asc' | 'desc';

export default function EmailTable() {
  const [emails, setEmails] = useState<Email[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  // Sorting
  const [sortField, setSortField] = useState<SortField>('id');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 10;

  const [deleteModal, setDeleteModal] = useState(false);
  const [selectedEmail, setSelectedEmail] =
    useState<Email | null>(null);

  // Reset Password Modal
  const [resetModal, setResetModal] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const fetchEmails = async () => {
    try {
      const response = await fetch('/api/emails');

      if (!response.ok) {
        throw new Error('Failed to fetch emails');
      }

      const data = await response.json();

      setEmails(data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    const loadEmails = async () => {
      setLoading(true);
      await fetchEmails();
      setLoading(false);
    };

    loadEmails();
  }, []);

  const handleDelete = async () => {
    if (!selectedEmail) return;

    try {
      const response = await fetch(
        `/api/emails/${selectedEmail.id}`,
        {
          method: 'DELETE',
        }
      );

      if (!response.ok) {
        throw new Error('Delete failed');
      }

      setDeleteModal(false);
      setSelectedEmail(null);

      await fetchEmails();
    } catch (error) {
      console.error(error);
      alert('Delete failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
    setCurrentPage(1);
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown size={14} className="text-slate-500" />;
    }
    return sortOrder === 'asc' ? (
      <ArrowUp size={14} className="text-cyan-400" />
    ) : (
      <ArrowDown size={14} className="text-cyan-400" />
    );
  };

  const filteredEmails = emails.filter((email) => {
    const matchesSearch = email.email
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchesStatus =
      statusFilter === 'all'
        ? true
        : email.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleExportCSV = () => {
    const headers = ['ID', 'Email', 'Status'];

    const rows = filteredEmails.map((email) => [
      email.id,
      email.email,
      email.status,
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row) => row.join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;',
    });

    const url = window.URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'email-records.csv');

    document.body.appendChild(link);
    link.click();

    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  const sortedEmails = [...filteredEmails].sort((a, b) => {
    const direction = sortOrder === 'asc' ? 1 : -1;

    if (sortField === 'id') {
      return (a.id - b.id) * direction;
    }

    return a[sortField]
      .localeCompare(b[sortField]) * direction;
  });

  const totalEmails = emails.length;

  const activeEmails = emails.filter(
    (email) => email.status === 'active'
  ).length;

  const disabledEmails = emails.filter(
    (email) => email.status === 'disabled'
  ).length;

  const totalPages = Math.ceil(
    filteredEmails.length / ITEMS_PER_PAGE
  );

  const paginatedEmails = sortedEmails.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  return (
    <>
      {/* Search */}
      <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search company email..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full rounded-xl border border-slate-700 bg-[#0F172A] py-3 pl-12 pr-4 text-white placeholder:text-slate-500 outline-none transition focus:border-cyan-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="rounded-xl border border-slate-700 bg-[#0F172A] px-4 py-3 text-white outline-none focus:border-cyan-500"
          >
            <option value="all">All</option>
            <option value="active">Active</option>
            <option value="disabled">Disabled</option>
          </select>

          <div className="rounded-xl bg-cyan-500/10 px-5 py-3">
            <span className="font-semibold text-cyan-400">
              {filteredEmails.length} Total Emails
            </span>
          </div>

          <button
            onClick={handleExportCSV}
            className="rounded-xl bg-green-600 px-5 py-3 font-semibold text-white transition hover:bg-green-700"
          >
            Export CSV
          </button>
        </div>
      </div>

      {/* Status Counter Cards */}
      <div className="mb-6 flex flex-wrap gap-3">
        <button
          onClick={() => {
            setStatusFilter('all');
            setCurrentPage(1);
          }}
          className={`rounded-xl px-5 py-3 font-semibold transition ${
            statusFilter === 'all'
              ? 'bg-cyan-600 text-white'
              : 'border border-slate-700 bg-[#0F172A] text-slate-300'
          }`}
        >
          All ({totalEmails})
        </button>

        <button
          onClick={() => {
            setStatusFilter('active');
            setCurrentPage(1);
          }}
          className={`rounded-xl px-5 py-3 font-semibold transition ${
            statusFilter === 'active'
              ? 'bg-green-600 text-white'
              : 'border border-slate-700 bg-[#0F172A] text-slate-300'
          }`}
        >
          Active ({activeEmails})
        </button>

        <button
          onClick={() => {
            setStatusFilter('disabled');
            setCurrentPage(1);
          }}
          className={`rounded-xl px-5 py-3 font-semibold transition ${
            statusFilter === 'disabled'
              ? 'bg-red-600 text-white'
              : 'border border-slate-700 bg-[#0F172A] text-slate-300'
          }`}
        >
          Disabled ({disabledEmails})
        </button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-[#111827]">
        <table className="min-w-[800px] w-full">
          <thead className="bg-[#0F172A]">
            <tr>
              <th className="px-6 py-4 text-left text-sm font-semibold text-slate-400">
                <button
                  onClick={() => handleSort('id')}
                  className="flex items-center gap-1.5 hover:text-white transition"
                >
                  ID {renderSortIcon('id')}
                </button>
              </th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-slate-400">
                <button
                  onClick={() => handleSort('email')}
                  className="flex items-center gap-1.5 hover:text-white transition"
                >
                  Email Address {renderSortIcon('email')}
                </button>
              </th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-slate-400">
                <button
                  onClick={() => handleSort('status')}
                  className="flex items-center gap-1.5 hover:text-white transition"
                >
                  Status {renderSortIcon('status')}
                </button>
              </th>
              <th className="px-6 py-4 text-center text-sm font-semibold text-slate-400">
                Actions
              </th>
            </tr>
          </thead>

          <tbody>
            {loading ? (
              <tr>
                <td colSpan={4} className="py-16 text-center text-slate-400">
                  Loading Emails...
                </td>
              </tr>
            ) : filteredEmails.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-16 text-center">
                  <Mail className="mx-auto mb-4 h-10 w-10 text-slate-600" />
                  <h3 className="text-xl font-semibold text-white">
                    No Email Found
                  </h3>
                  <p className="mt-2 text-slate-400">
                    There are no email records available.
                  </p>
                </td>
              </tr>
            ) : (
              paginatedEmails.map((email) => (
                <tr
                  key={email.id}
                  className="border-t border-slate-800 hover:bg-slate-800/40 transition"
                >
                  <td className="px-6 py-5 text-slate-300">
                    #{email.id}
                  </td>

                  <td className="px-6 py-5 font-medium text-white">
                    {email.email}
                  </td>

                  <td className="px-6 py-5">
                    <span
                      className={`rounded-full px-3 py-1 text-xs font-semibold ${
                        email.status === 'active'
                          ? 'bg-green-500/10 text-green-400'
                          : 'bg-red-500/10 text-red-400'
                      }`}
                    >
                      {email.status}
                    </span>
                  </td>

                  <td className="px-6 py-5">
                    <div className="flex justify-center gap-3">
                      <Link
                        href={`/emails/${email.id}`}
                        className="rounded-lg border border-cyan-500 p-2 text-cyan-400 transition hover:bg-cyan-500 hover:text-white"
                        title="View"
                      >
                        <Eye size={18} />
                      </Link>

                      <button
                        onClick={() => {
                          setSelectedEmail(email);
                          setNewPassword('');
                          setConfirmPassword('');
                          setShowPassword(false);
                          setResetModal(true);
                        }}
                        className="rounded-lg border border-yellow-500 p-2 text-yellow-400 transition hover:bg-yellow-500 hover:text-white"
                        title="Reset Password"
                      >
                        <RotateCcw size={18} />
                      </button>

                      <button
                        onClick={() => {
                          setSelectedEmail(email);
                          setDeleteModal(true);
                        }}
                        className="rounded-lg border border-red-500 p-2 text-red-400 transition hover:bg-red-600 hover:text-white"
                        title="Delete"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2 px-2">
          <button
            onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
            disabled={currentPage === 1}
            className="rounded-lg border border-slate-700 px-3 py-2 text-sm text-white disabled:opacity-50"
          >
            Previous
          </button>

          {Array.from({ length: totalPages }, (_, index) => (
            <button
              key={index}
              onClick={() => setCurrentPage(index + 1)}
              className={`rounded-lg px-3 py-2 text-sm transition ${
                currentPage === index + 1
                  ? 'bg-cyan-500 text-white'
                  : 'border border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {index + 1}
            </button>
          ))}

          <button
            onClick={() =>
              setCurrentPage((p) => Math.min(p + 1, totalPages))
            }
            disabled={currentPage === totalPages}
            className="rounded-lg border border-slate-700 px-3 py-2 text-sm text-white disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}

      {/* Delete Modal */}
      {deleteModal && selectedEmail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-700 bg-[#111827] p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">
                  Delete Email
                </h2>
                <p className="mt-1 text-sm text-slate-400">
                  This action cannot be undone.
                </p>
              </div>

              <button
                onClick={() => {
                  setDeleteModal(false);
                  setSelectedEmail(null);
                }}
                className="rounded-lg p-2 hover:bg-slate-800 transition"
              >
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>

            <div className="mt-6 rounded-xl border border-red-500/20 bg-red-500/10 p-4">
              <p className="text-sm text-slate-300">
                You are about to permanently delete:
              </p>
              <p className="mt-3 break-all text-lg font-semibold text-red-400">
                {selectedEmail.email}
              </p>
            </div>

            <div className="mt-8 flex justify-end gap-3">
              <button
                onClick={() => {
                  setDeleteModal(false);
                  setSelectedEmail(null);
                }}
                className="rounded-xl border border-slate-600 bg-slate-800 px-5 py-2.5 text-white transition hover:bg-slate-700"
              >
                Cancel
              </button>

              <button
                onClick={handleDelete}
                className="rounded-xl bg-red-600 px-5 py-2.5 font-semibold text-white transition hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Password Modal */}
      {resetModal && selectedEmail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-700 bg-[#111827] p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">
                  Reset Password
                </h2>
                <p className="mt-1 text-sm text-slate-400">
                  {selectedEmail.email}
                </p>
              </div>

              <button
                onClick={() => setResetModal(false)}
                className="rounded-lg p-2 hover:bg-slate-800"
              >
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>

            <div className="mt-6">
              <label className="mb-2 block text-sm text-slate-400">
                New Password
              </label>

              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full rounded-xl border border-slate-700 bg-[#0F172A] px-4 py-3 pr-12 text-white outline-none focus:border-cyan-500"
                />

                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="mt-5">
              <label className="mb-2 block text-sm text-slate-400">
                Confirm Password
              </label>

              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm password"
                className="w-full rounded-xl border border-slate-700 bg-[#0F172A] px-4 py-3 text-white outline-none focus:border-cyan-500"
              />
            </div>

            <div className="mt-8 flex justify-end gap-3">
              <button
                onClick={() => setResetModal(false)}
                className="rounded-xl border border-slate-600 bg-slate-800 px-5 py-2.5 text-white"
              >
                Cancel
              </button>

              <button
                onClick={async () => {
                  if (newPassword.length < 8) {
                    alert('Password must be at least 8 characters.');
                    return;
                  }

                  if (newPassword !== confirmPassword) {
                    alert('Passwords do not match.');
                    return;
                  }

                  try {
                    const response = await fetch(
                      `/api/emails/${selectedEmail?.id}`,
                      {
                        method: 'PATCH',
                        headers: {
                          'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                          password: newPassword,
                        }),
                      }
                    );

                    const data = await response.json();

                    if (!response.ok) {
                      alert(data.message || 'Failed to reset password.');
                      return;
                    }

                    alert('Password reset successfully.');

                    setResetModal(false);
                    setNewPassword('');
                    setConfirmPassword('');

                    await fetchEmails();
                  } catch (error) {
                    console.error(error);
                    alert('Something went wrong.');
                  }
                }}
                className="rounded-xl bg-yellow-500 px-5 py-2.5 font-semibold text-black hover:bg-yellow-400"
              >
                Reset Password
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}